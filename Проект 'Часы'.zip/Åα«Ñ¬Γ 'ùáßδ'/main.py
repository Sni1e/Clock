from tkinter import *
import time

screen = Tk()
screen.geometry('600x300')
screen.title('Часы')
screen.resizable(False, False)


def timing():
    hms = time.localtime()
    x = time.strftime('%H:%M:%S', hms)
    lbl.config(text=x)
    lbl.after(200, timing)


lbl = Label(screen,
            font=('times', 70, 'bold'))
lbl.place(width=600, height=80, x=0, y=75)

lbl_1 = Label(screen,
              text='    Часы     минуты    секунды',
              font=('times', 24))
lbl_1.place(width=600, height=40, x=0, y=160)

timing()
screen.mainloop()
